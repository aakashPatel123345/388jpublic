# Stores all configuration values
SECRET_KEY = '\xfaR\x11\xa7p\x197\xf6\xf0\xf7\x1e\xadj\xc5\xde\xc4'
MONGODB_HOST = 'mongodb+srv://aakashpatel0377:mongoDBAakashMM@cluster0.tuubvqi.mongodb.net/cmsc388j_db?retryWrites=true&w=majority&appName=Cluster0'
